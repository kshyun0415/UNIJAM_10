using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Random = System.Random;
public class Trash : MonoBehaviour
{
    Random random = new Random();
    int num1, num2;

    void Start()
    {

    }


    void Update()
    {

    }


}
